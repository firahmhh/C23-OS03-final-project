package id.fishku.fishkuseller.api

interface ApiService {

    interface ApiService

}